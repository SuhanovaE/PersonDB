﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SqlDB.Classes;
using System.Drawing;

namespace SqlDB.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
    public partial class AddEditPage : Page

        //новое поле, которое будет хранить в себе экземпляры добавляемого пользователя
    {    
        private Person _currentPerson = new Person();
        public AddEditPage(Person selectedPerson)
        {//создаём контекст         
           
            InitializeComponent();
            if (selectedPerson != null)
                _currentPerson = selectedPerson;
            DataContext = _currentPerson;
            //ComboAges.ItemsSource = TestEntities.GetContext().Person.ToList();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentPerson.LastName))
                error.AppendLine("Укажите фамилию");
            if (string.IsNullOrWhiteSpace(_currentPerson.FirstName))
                error.AppendLine("Укажите имя");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentPerson.ID == 0)
                TestEntities.GetContext().Person.Add(_currentPerson);
            try
            {
                TestEntities.GetContext().SaveChanges();
                MessageBox.Show("Новый пользователь добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        //private void ComboAges_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    int[] ages = {16, 17, 18, 19, 20};
        //    ComboAges.Items.Add(16);
        //}
    }
}
